﻿Public Class Form15

    Private Sub Form15_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'PassdetDataSet.Passenger' table. You can move, or remove it, as needed.
        Me.PassengerTableAdapter.Fill(Me.PassdetDataSet.Passenger)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        PassengerBindingSource.RemoveCurrent()
        Form16.Show()
        Me.Hide()
    End Sub
End Class