﻿Partial Class PassdetDataSet
End Class
