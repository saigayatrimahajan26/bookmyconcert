﻿Public Class Form4

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedItem = 1001 Then
            Form5.Show()
        End If
        If ListBox1.SelectedItem = 1002 Then
            Form6.Show()
        End If
        If ListBox1.SelectedItem = 1003 Then
            Form7.Show()
        End If
        
        Me.Hide()

    End Sub
End Class